const express = require('express');
const { getAllProducts, getProductDetails } = require('../controllers/productController');
const router = express.Router();

router.get('/', getAllProducts);
router.get('/:id', getProductDetails);

module.exports = router;
