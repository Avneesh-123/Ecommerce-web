const fs = require('fs');
const path = require('path');

// Load product data from JSON file
const products = JSON.parse(fs.readFileSync(path.join(__dirname, '../products.json')));

const getAllProducts = (req, res) => {
  res.json(products);
};

const getProductDetails = (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (product) {
    res.json(product);
  } else {
    res.status(404).json({ message: 'Product not found' });
  }
};

module.exports = { getAllProducts, getProductDetails };
