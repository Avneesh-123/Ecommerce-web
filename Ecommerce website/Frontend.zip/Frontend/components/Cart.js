import React from 'react';
import { Link } from 'react-router-dom';

function Cart() {
  const cartItems = []; // Example cart items

  return (
    <div>
      <h1>My Cart</h1>
      {cartItems.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <ul>
          {cartItems.map(item => (
            <li key={item.id}>
              {item.name} - {item.quantity} x ${item.price}
            </li>
          ))}
        </ul>
      )}
      <Link to="/checkout">Proceed to Checkout</Link>
    </div>
  );
}

export default Cart;
