import React from 'react';

function Checkout() {
  return (
    <div>
      <h1>Checkout</h1>
      <p>Order Summary</p>
      <button>Cash on Delivery</button>
    </div>
  );
}

export default Checkout;
