import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/api/products/${id}`)
      .then(response => response.json())
      .then(data => setProduct(data));
  }, [id]);

  const handleAddToCart = () => {
    // Logic for adding to cart
    alert('Added to cart');
  };

  const handleBuyNow = () => {
    // Check if the user is authenticated
    const isAuthenticated = false;  // Simulate authentication check

    if (!isAuthenticated) {
      alert('Please log in to proceed');
      navigate('/login');
    } else {
      navigate('/checkout');
    }
  };

  if (!product) return <div>Loading...</div>;

  return (
    <div>
      <img src={product.image} alt={product.name} />
      <h1>{product.name}</h1>
      <p>{product.description}</p>
      <p>${product.price}</p>
      <button onClick={handleAddToCart}>Add to Cart</button>
      <button onClick={handleBuyNow}>Buy Now</button>
    </div>
  );
}

export default ProductDetail;
